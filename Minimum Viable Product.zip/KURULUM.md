# Sağlık Takip - Kurulum

Bu klasör bir Flutter projesinin `lib/` kodunu ve `pubspec.yaml` dosyasını içerir.
Android/iOS klasörlerini Flutter oluşturur.

## 1. Projeyi oluştur

```bash
flutter create saglik_takip --org com.ornek --platforms android,ios
```

Sonra bu klasördeki `lib/` klasörünü ve `pubspec.yaml` dosyasını oluşan projenin içine kopyala
(mevcut `lib/main.dart` ve `pubspec.yaml` üzerine yaz). Ardından:

```bash
flutter pub get
```

## 2. Android ayarları (bildirimler için zorunlu)

**android/app/build.gradle(.kts)** içinde, `compileOptions` bloğuna ve `dependencies` bloğuna ekle
(Kotlin DSL kullanıyorsan `isCoreLibraryDesugaringEnabled = true`):

```gradle
android {
    compileOptions {
        coreLibraryDesugaringEnabled true
    }
}
dependencies {
    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'
}
```

**android/app/src/main/AndroidManifest.xml** içinde `<manifest>` altına izinleri,
`<application>` içine alıcıları ekle (telefon yeniden başlayınca alarmlar korunur):

```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>

<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
<receiver android:exported="false"
    android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
    <intent-filter>
        <action android:name="android.intent.action.BOOT_COMPLETED"/>
        <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
        <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
        <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
    </intent-filter>
</receiver>
```

## 3. Çalıştır

```bash
flutter run
```

## Notlar

- Bildirimler `inexactAllowWhileIdle` ile kurulur; saniyesi saniyesine değil, belirlenen saatte
  birkaç dakika sapmayla gelebilir. Tam zamanlı alarm gerekirse ek izin gerekir.
- iOS en fazla 64 bekleyen yerel bildirime izin verir. Çok ürün eklenecekse ileride en yakın
  tarihli bildirimleri öncelikli planlamak gerekir.
- Bildirim kimliği `ürün id * 100 + gün` olarak üretilir; bu yüzden gün seçenekleri 0-99 arasında kalmalı.
- Bu kod bu ortamda derlenip çalıştırılmadı (Flutter kurulu değildi). İlk `flutter run` sırasında
  paket sürümü kaynaklı küçük hatalar çıkabilir.
